﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EFCoreDemo.Models
{
    public class Book
    {
        public int BookId { get; set; }
        public string Title { get; set; }
        public string Isbn10 { get; set; }
        public int PublicationYear { get; set; }
        public List<BookAuthor> BookAuthors { get; set; }
    }
}
